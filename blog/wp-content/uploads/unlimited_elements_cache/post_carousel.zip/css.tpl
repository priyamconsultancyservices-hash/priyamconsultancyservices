#{{uc_id}}-wrapper{
  min-height:1px;
}

#{{uc_id}} *{
  box-sizing:border-box;
}

#{{uc_id}} .ue-grid-item-category a{
  white-space: nowrap;
}

{% if add_coma_between_categories == "true" %}
  #{{uc_id}} .ue-grid-item-category a:not(:last-child)::after{
      content: ", ";
  }
{% endif %}

#{{uc_id}}{
  position:relative;
}

.uc_post_title{
  font-size:21px;
}

#{{uc_id}} .ue-item{
  transition:0.3s;
  position:relative;
}

#{{uc_id}} .uc_image_carousel_placeholder{
  position:relative;
}

#{{uc_id}} .ue_pos_carousel_image_overlay{
  position:absolute;
  top:0;
  bottom:0;
  left:0;
  right:0;
  transition:0.3s;
}

#{{uc_id}} .owl-stage{
  display:flex;
}

#{{uc_id}} .uc_image_carousel_container_holder{
  display: flex;
  flex-direction: column;
  height: 100%;
}

#{{uc_id}} .uc_image_carousel_content{
  flex-grow: 1;
  {% if align_button_same_height == "true" %}justify-content: space-between;{% endif %}
}


#{{uc_id}} .uc_carousel_item{
  overflow:hidden;
}

#{{uc_id}} .owl-nav .owl-prev{
    position:absolute;
    display:inline-block;
    text-align:center;  	
    {% if arrows_vertical_align_middle == "true" %}
        top: 50% !important;
  		transform: translate(0, -50%);
    {% endif %}	
}

#{{uc_id}} .owl-nav .owl-next{
  position:absolute;
  display:inline-block;
  text-align:center;
  {% if arrows_vertical_align_middle == "true" %}
      top: 50% !important;
  	  transform: translate(0, -50%);
  {% endif %}	
}

#{{uc_id}} .owl-dots {
  overflow:hidden;
  display:{{show_dots}} !important;
}

#{{uc_id}} .owl-dot {
  border-radius:50%;
  display:inline-block;
  padding: 0;
}

#{{uc_id}} .uc_more_btn{
  display:{{button_style}};
  text-align:center;
  text-decoration:none;
}  

#{{uc_id}} .uc_more_btn svg{
  width:1em;
  height:1em;
}

#{{uc_id}} .uc_image_carousel_placeholder{
  overflow:hidden;
}

#{{uc_id}} .uc_image_carousel_placeholder img{
  display:block;
  width:100%;
}

#{{uc_id}} .uc_image_carousel_content {
  display:flex;
  flex-direction:column;
}

{% if button_align_to_bottom == "true" %}
	#{{uc_id}} .uc_image_carousel_content .ue-item-btn-holder    {
      margin-top:auto;
    } 
{% endif %}	

{% if layout == "overlay" %}
	#{{uc_id}} .uc_image_carousel_content    {
      position:absolute;
      top:0px;
      left:0px;
      bottom:0px;
      right:0px;
      opacity:0;
      transition:1s;
      display:flex;
      align-items:center;
      flex-direction:column;
      justify-content: center;
    }

	#{{uc_id}} .uc_image_carousel_container_holder:hover .uc_image_carousel_content{
      opacity:1;
    }
{% endif %}


{% if layout == "overlay_bottom" %}
	#{{uc_id}} .uc_image_carousel_content    {
      position:absolute;
      left:0px;
      bottom:0px;
      right:0px;
      transition:0.3s;
    }
{% endif %}


{% if layout == "partial_overlay" %}
	#{{uc_id}} .uc_image_carousel_content{
     position:absolute;
    }
{% endif %}

{% if layout == "under_overlap" %}
	#{{uc_id}} .uc_image_carousel_content{
     margin-left:20px;
      margin-right:20px;
      margin-top:-30px;
      position:relative;
    }
{% endif %}

{% if layout == "reveal_from_bottom" %}
	#{{uc_id}} .uc_image_carousel_content{
        margin-left:0px;
        margin-right:0px;
        margin-top:0px;
        position:absolute;
      	bottom: -100%;
        left: 0;
        right: 0;
        transition: ease-in-out all 0.25s;
      	-webkit-transition: ease-in-out all 0.25s;
    }
    #{{uc_id}} .uc_image_carousel_container_holder:hover .uc_image_carousel_content{
		bottom: 0;
    }
{% endif %}

{% if layout == "side_by_side" %}
  #{{uc_id}} .uc_carousel_item{
    display:flex;
    {% if reverse_sides == "false" %}
    flex-direction:row;
    {% else %}
    flex-direction:row-reverse;
    {% endif %}
  }

  #{{uc_id}} .uc_image_carousel_placeholder{
    width:50%;
  }

  #{{uc_id}} .uc_image_carousel_content{
    width:50%;
    display:flex;
    flex-direction:column;
    justify-content:center;
  }
{% endif %}

#{{uc_id}} .ue-meta-data{  
  display:flex !important;
  flex-wrap: wrap;
  line-height:1em;
}

#{{uc_id}} .ue-grid-item-meta-data{
      display:inline-flex;
      align-items:center;
}

.ue-grid-item-meta-data{
  font-size:12px;
}

#{{uc_id}} .ue-grid-item-meta-data-icon{
  line-height:1em;
}

#{{uc_id}} .ue-grid-item-meta-data-icon svg{
  width:1em;
  height:1em;
}

#{{uc_id}} .ue-debug-meta{
  padding:10px;
  border:1px solid red;
  position:relative;
  line-height:1.5em;
  font-size:11px;
  width:100%;
}

{% if link_complete_item == "true" %}
  #{{uc_id}} .ue-item a.ue-link-all-item  {
    position:absolute;
    top:0;
    right:0;
    bottom:0;
    left:0;
    display:block;
  }
{% endif %}

{% if transition_easing == "false" %}
	#{{uc_id}} .owl-stage        {
            transition-timing-function: linear!important;
        }
{% endif %}

#{{uc_id}} .owl-nav .owl-prev.disabled,
#{{uc_id}} .owl-nav .owl-next.disabled {
   display: none;
}